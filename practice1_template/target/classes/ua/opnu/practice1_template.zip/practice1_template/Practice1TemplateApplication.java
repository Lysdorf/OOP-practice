package ua.opnu.practice1_template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice1TemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practice1TemplateApplication.class, args);
	}

}
